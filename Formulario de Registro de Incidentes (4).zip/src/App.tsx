import { useState, useRef, useEffect } from "react";

// ── Types ──────────────────────────────────────────────────────────────────
type Tab = "incidentes" | "asignacion" | "rutas" | "inventario";
type ReportStep = 0 | 1 | 2 | 3 | 4 | 5;

interface Resource {
  id: string;
  tipo: "Ambulancia" | "Bomberos" | "Rescate";
  unidad: string;
  estado: "Disponible" | "En servicio" | "Mantenimiento";
  ubicacion: string;
  distancia: number;
  prioridad: number;
}

interface Incident {
  tipo: string;
  descripcion: string;
  nivel: string;
  victimas: string;
}

// ── Graph Node ─────────────────────────────────────────────────────────────
interface GraphNode {
  id: string;
  label: string;
  x: number;
  y: number;
  type: "incident" | "unit" | "hospital" | "base";
  active?: boolean;
}

interface GraphEdge {
  from: string;
  to: string;
  weight: number;
  optimal?: boolean;
}

const GRAPH_NODES: GraphNode[] = [
  { id: "INC", label: "INCIDENTE", x: 50, y: 50, type: "incident", active: true },
  { id: "A1",  label: "AMB-01",    x: 15, y: 20, type: "unit" },
  { id: "A2",  label: "AMB-02",    x: 80, y: 15, type: "unit" },
  { id: "B1",  label: "BOM-01",    x: 10, y: 75, type: "unit" },
  { id: "R1",  label: "RES-01",    x: 85, y: 70, type: "unit" },
  { id: "H1",  label: "HOSPITAL",  x: 50, y: 88, type: "hospital" },
  { id: "H2",  label: "CLÍNICA",   x: 25, y: 88, type: "hospital" },
  { id: "BASE",label: "BASE",      x: 70, y: 88, type: "base" },
];

const GRAPH_EDGES: GraphEdge[] = [
  { from: "A1",  to: "INC", weight: 3.2, optimal: true  },
  { from: "A2",  to: "INC", weight: 6.8 },
  { from: "B1",  to: "INC", weight: 4.1 },
  { from: "R1",  to: "INC", weight: 5.5 },
  { from: "INC", to: "H1",  weight: 2.1, optimal: true  },
  { from: "INC", to: "H2",  weight: 3.9 },
  { from: "A1",  to: "BASE",weight: 7.2 },
  { from: "B1",  to: "H2",  weight: 5.0 },
  { from: "R1",  to: "BASE",weight: 3.3 },
];

// ── Data ───────────────────────────────────────────────────────────────────
const RESOURCES: Resource[] = [
  { id: "AMB-01", tipo: "Ambulancia", unidad: "Unidad Alpha",   estado: "Disponible",    ubicacion: "Av. Central 12",    distancia: 3.2, prioridad: 1 },
  { id: "AMB-02", tipo: "Ambulancia", unidad: "Unidad Beta",    estado: "Disponible",    ubicacion: "Calle Norte 88",    distancia: 6.8, prioridad: 3 },
  { id: "BOM-01", tipo: "Bomberos",   unidad: "Compañía 4",     estado: "Disponible",    ubicacion: "Estación Sur 3",    distancia: 4.1, prioridad: 2 },
  { id: "BOM-02", tipo: "Bomberos",   unidad: "Compañía 7",     estado: "En servicio",   ubicacion: "Zona Industrial",   distancia: 9.4, prioridad: 5 },
  { id: "RES-01", tipo: "Rescate",    unidad: "Equipo Delta",   estado: "Disponible",    ubicacion: "Base Central",      distancia: 5.5, prioridad: 4 },
  { id: "RES-02", tipo: "Rescate",    unidad: "Equipo Gamma",   estado: "Mantenimiento", ubicacion: "Depósito Norte",    distancia: 12.0, prioridad: 6 },
];

const TIPO_INCIDENTE = ["Accidente vial", "Incendio estructural", "Emergencia médica", "Rescate en altura", "Inundación", "Derrumbe"];
const NIVEL_PRIORIDAD = ["P1 — Crítico", "P2 — Alto", "P3 — Moderado", "P4 — Bajo"];

// ── Graph Canvas ───────────────────────────────────────────────────────────
function GraphView({ highlightOptimal }: { highlightOptimal: boolean }) {
  const svgW = 340;
  const svgH = 220;
  const toX = (pct: number) => (pct / 100) * svgW;
  const toY = (pct: number) => (pct / 100) * svgH;

  const nodeById = (id: string) => GRAPH_NODES.find(n => n.id === id)!;

  const nodeColor: Record<GraphNode["type"], string> = {
    incident: "#e63946",
    unit:     "#1d8cf8",
    hospital: "#2dc653",
    base:     "#f4a261",
  };

  return (
    <svg width={svgW} height={svgH} className="w-full h-auto" style={{ background: "#080c12" }}>
      {/* grid lines */}
      {[0, 25, 50, 75, 100].map(v => (
        <line key={`h${v}`} x1={0} y1={toY(v)} x2={svgW} y2={toY(v)} stroke="#1e2d42" strokeWidth={0.5} />
      ))}
      {[0, 25, 50, 75, 100].map(v => (
        <line key={`v${v}`} x1={toX(v)} y1={0} x2={toX(v)} y2={svgH} stroke="#1e2d42" strokeWidth={0.5} />
      ))}

      {/* edges */}
      {GRAPH_EDGES.map((e, i) => {
        const a = nodeById(e.from);
        const b = nodeById(e.to);
        const opt = highlightOptimal && e.optimal;
        return (
          <g key={i}>
            <line
              x1={toX(a.x)} y1={toY(a.y)} x2={toX(b.x)} y2={toY(b.y)}
              stroke={opt ? "#e63946" : "#1e2d42"}
              strokeWidth={opt ? 2 : 1}
              strokeDasharray={opt ? undefined : "4 3"}
              opacity={opt ? 1 : 0.6}
            />
            {/* weight label */}
            <text
              x={(toX(a.x) + toX(b.x)) / 2}
              y={(toY(a.y) + toY(b.y)) / 2 - 3}
              fill={opt ? "#e63946" : "#2a3f5a"}
              fontSize={8}
              textAnchor="middle"
              fontFamily="JetBrains Mono"
            >
              {e.weight}km
            </text>
          </g>
        );
      })}

      {/* nodes */}
      {GRAPH_NODES.map(n => (
        <g key={n.id}>
          <circle
            cx={toX(n.x)} cy={toY(n.y)} r={n.type === "incident" ? 10 : 7}
            fill={nodeColor[n.type]}
            opacity={0.15}
          />
          <circle
            cx={toX(n.x)} cy={toY(n.y)} r={n.type === "incident" ? 6 : 4}
            fill={nodeColor[n.type]}
          />
          <text
            x={toX(n.x)}
            y={toY(n.y) - (n.type === "incident" ? 13 : 10)}
            fill={nodeColor[n.type]}
            fontSize={7}
            textAnchor="middle"
            fontFamily="JetBrains Mono"
            fontWeight="600"
          >
            {n.label}
          </text>
        </g>
      ))}
    </svg>
  );
}

// ── Status badge ───────────────────────────────────────────────────────────
function StatusBadge({ estado }: { estado: Resource["estado"] }) {
  const map = {
    "Disponible":    "text-green-400 bg-green-400/10 border-green-400/30",
    "En servicio":   "text-amber-400 bg-amber-400/10 border-amber-400/30",
    "Mantenimiento": "text-slate-400 bg-slate-400/10 border-slate-400/30",
  };
  return (
    <span className={`text-xs font-mono px-2 py-0.5 border rounded-sm ${map[estado]}`}>
      {estado}
    </span>
  );
}

// ── Report workflow ────────────────────────────────────────────────────────
const STEPS = [
  { label: "Clasificar tipo",              desc: "Identificar categoría del incidente" },
  { label: "Buscar recurso disponible",    desc: "Consultar inventario en tiempo real" },
  { label: "Evaluar prioridad",            desc: "Algoritmo de ponderación por urgencia" },
  { label: "Seleccionar recurso cercano",  desc: "Dijkstra: ruta de menor costo" },
  { label: "Asignar unidad",               desc: "Despachar y notificar unidad asignada" },
];

// ── Main App ───────────────────────────────────────────────────────────────
export default function App() {
  const [address, setAddress] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>("incidentes");
  const [reportStep, setReportStep] = useState<ReportStep>(0);
  const [incident, setIncident] = useState<Incident>({ tipo: "", descripcion: "", nivel: "", victimas: "" });
  const [assigned, setAssigned] = useState<Resource | null>(null);
  const [showGraph, setShowGraph] = useState(false);
  const formRef = useRef<HTMLDivElement>(null);

  const handleSubmitAddress = () => {
    if (address.trim().length < 5) return;
    setSubmitted(true);
    setTimeout(() => formRef.current?.scrollIntoView({ behavior: "smooth" }), 100);
  };

  const handleAssign = () => {
    const best = RESOURCES.filter(r => r.estado === "Disponible").sort((a, b) => a.distancia - b.distancia)[0];
    setAssigned(best);
    setReportStep(5);
  };

  const stepClass = (i: number) => {
    if (i < reportStep) return "step-done";
    if (i === reportStep) return "step-active";
    return "step-pending";
  };

  const tabs: { id: Tab; label: string }[] = [
    { id: "incidentes",  label: "Registro de incidentes" },
    { id: "asignacion",  label: "Asignación automática" },
    { id: "rutas",       label: "Rutas de emergencia" },
    { id: "inventario",  label: "Inventario de recursos" },
  ];

  return (
    <div className="min-h-screen" style={{ background: "#080c12", fontFamily: "Inter, sans-serif" }}>

      {/* ── Header ─────────────────────────────────────────────── */}
      <header style={{ background: "#0d1420", borderBottom: "1px solid #1e2d42" }} className="px-6 py-3 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="pulse-dot w-2 h-2 rounded-full bg-red-500" />
            <span style={{ fontFamily: "Barlow Condensed, sans-serif", color: "#e63946", fontSize: "1.25rem", fontWeight: 700, letterSpacing: "0.08em" }}>
              EMRG·SYS
            </span>
          </div>
          <span style={{ color: "#2a3f5a", fontSize: "0.7rem", fontFamily: "JetBrains Mono, monospace" }}>v2.4 · ACTIVO</span>
        </div>
        <div className="flex items-center gap-6">
          {[
            { label: "AMB", count: 2, color: "#1d8cf8" },
            { label: "BOM", count: 1, color: "#f4a261" },
            { label: "RES", count: 1, color: "#2dc653" },
          ].map(({ label, count, color }) => (
            <div key={label} className="flex items-center gap-1.5">
              <span style={{ color: "#5a7a99", fontSize: "0.65rem", fontFamily: "JetBrains Mono, monospace" }}>{label}</span>
              <span style={{ color, fontSize: "0.85rem", fontFamily: "JetBrains Mono, monospace", fontWeight: 600 }}>{count}</span>
            </div>
          ))}
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-10">

        {/* ── Address bar ────────────────────────────────────────── */}
        <div className="mb-8">
          <p style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "0.7rem", letterSpacing: "0.15em", color: "#5a7a99", textTransform: "uppercase" }} className="mb-2">
            Dirección del incidente
          </p>
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs" style={{ fontFamily: "JetBrains Mono, monospace", color: "#2a3f5a" }}>
                ▸
              </span>
              <input
                type="text"
                value={address}
                onChange={e => setAddress(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleSubmitAddress()}
                placeholder="Ej. Av. Insurgentes Sur 1234, Col. Del Valle, CDMX"
                style={{
                  background: "#0d1420",
                  border: `1px solid ${submitted ? "#e63946" : "#1e2d42"}`,
                  color: "#e2eaf4",
                  fontFamily: "Inter, sans-serif",
                  fontSize: "0.95rem",
                  outline: "none",
                  width: "100%",
                  padding: "0.75rem 0.75rem 0.75rem 2rem",
                  borderRadius: "2px",
                  transition: "border-color 0.15s",
                }}
                onFocus={e => { if (!submitted) e.target.style.borderColor = "#2a3f5a"; }}
                onBlur={e => { if (!submitted) e.target.style.borderColor = "#1e2d42"; }}
              />
            </div>
            <button
              onClick={handleSubmitAddress}
              disabled={address.trim().length < 5}
              style={{
                background: address.trim().length >= 5 ? "#e63946" : "#1e2d42",
                color: address.trim().length >= 5 ? "#fff" : "#2a3f5a",
                fontFamily: "Barlow Condensed, sans-serif",
                fontSize: "0.95rem",
                fontWeight: 700,
                letterSpacing: "0.1em",
                padding: "0.75rem 1.75rem",
                border: "none",
                borderRadius: "2px",
                cursor: address.trim().length >= 5 ? "pointer" : "default",
                transition: "background 0.15s",
                textTransform: "uppercase",
                whiteSpace: "nowrap",
              }}
            >
              Enviar →
            </button>
          </div>
          {submitted && (
            <p style={{ color: "#2dc653", fontSize: "0.72rem", fontFamily: "JetBrains Mono, monospace", marginTop: "0.4rem" }}>
              ✓ Dirección registrada — complete el formulario a continuación
            </p>
          )}
        </div>

        {/* ── Form panel ─────────────────────────────────────────── */}
        {submitted && (
          <div ref={formRef} style={{ border: "1px solid #1e2d42", borderRadius: "2px", background: "#0d1420" }}>

            {/* address pill */}
            <div style={{ borderBottom: "1px solid #1e2d42", padding: "0.6rem 1.25rem", background: "#111927" }} className="flex items-center gap-3">
              <span style={{ color: "#e63946", fontSize: "0.65rem", fontFamily: "JetBrains Mono, monospace", letterSpacing: "0.1em" }}>UBICACIÓN</span>
              <span style={{ color: "#e2eaf4", fontSize: "0.8rem", fontFamily: "Inter, sans-serif" }}>{address}</span>
            </div>

            {/* tabs */}
            <div style={{ borderBottom: "1px solid #1e2d42" }} className="flex overflow-x-auto">
              {tabs.map(t => (
                <button
                  key={t.id}
                  onClick={() => setActiveTab(t.id)}
                  className={activeTab === t.id ? "tab-active" : "tab-inactive"}
                  style={{
                    fontFamily: "Barlow Condensed, sans-serif",
                    fontSize: "0.85rem",
                    fontWeight: 600,
                    letterSpacing: "0.06em",
                    textTransform: "uppercase",
                    padding: "0.65rem 1.1rem",
                    border: "none",
                    borderBottom: activeTab === t.id ? "2px solid #e63946" : "2px solid transparent",
                    whiteSpace: "nowrap",
                    cursor: "pointer",
                    transition: "all 0.15s",
                    background: "transparent",
                    color: activeTab === t.id ? "#e63946" : "#5a7a99",
                  }}
                >
                  {t.label}
                </button>
              ))}
            </div>

            <div className="p-6">

              {/* ── Tab: Registro de incidentes ───────────────── */}
              {activeTab === "incidentes" && (
                <div>
                  <h2 style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "1.4rem", fontWeight: 700, color: "#e2eaf4", letterSpacing: "0.05em", marginBottom: "1.25rem", textTransform: "uppercase" }}>
                    Registro de Incidente
                  </h2>
                  <div className="grid gap-4" style={{ gridTemplateColumns: "1fr 1fr" }}>
                    <div>
                      <label style={{ color: "#5a7a99", fontSize: "0.68rem", fontFamily: "JetBrains Mono, monospace", letterSpacing: "0.1em", display: "block", marginBottom: "0.35rem" }}>
                        TIPO DE INCIDENTE *
                      </label>
                      <select
                        value={incident.tipo}
                        onChange={e => setIncident(p => ({ ...p, tipo: e.target.value }))}
                        style={{ width: "100%", background: "#111927", border: "1px solid #1e2d42", color: "#e2eaf4", padding: "0.6rem 0.75rem", borderRadius: "2px", fontFamily: "Inter, sans-serif", fontSize: "0.875rem", outline: "none" }}
                      >
                        <option value="">— Seleccionar —</option>
                        {TIPO_INCIDENTE.map(t => <option key={t} value={t}>{t}</option>)}
                      </select>
                    </div>
                    <div>
                      <label style={{ color: "#5a7a99", fontSize: "0.68rem", fontFamily: "JetBrains Mono, monospace", letterSpacing: "0.1em", display: "block", marginBottom: "0.35rem" }}>
                        NIVEL DE PRIORIDAD *
                      </label>
                      <select
                        value={incident.nivel}
                        onChange={e => setIncident(p => ({ ...p, nivel: e.target.value }))}
                        style={{ width: "100%", background: "#111927", border: "1px solid #1e2d42", color: "#e2eaf4", padding: "0.6rem 0.75rem", borderRadius: "2px", fontFamily: "Inter, sans-serif", fontSize: "0.875rem", outline: "none" }}
                      >
                        <option value="">— Seleccionar —</option>
                        {NIVEL_PRIORIDAD.map(n => <option key={n} value={n}>{n}</option>)}
                      </select>
                    </div>
                    <div>
                      <label style={{ color: "#5a7a99", fontSize: "0.68rem", fontFamily: "JetBrains Mono, monospace", letterSpacing: "0.1em", display: "block", marginBottom: "0.35rem" }}>
                        VÍCTIMAS ESTIMADAS
                      </label>
                      <input
                        type="number"
                        min="0"
                        value={incident.victimas}
                        onChange={e => setIncident(p => ({ ...p, victimas: e.target.value }))}
                        placeholder="0"
                        style={{ width: "100%", background: "#111927", border: "1px solid #1e2d42", color: "#e2eaf4", padding: "0.6rem 0.75rem", borderRadius: "2px", fontFamily: "Inter, sans-serif", fontSize: "0.875rem", outline: "none" }}
                      />
                    </div>
                    <div style={{ gridColumn: "span 2" }}>
                      <label style={{ color: "#5a7a99", fontSize: "0.68rem", fontFamily: "JetBrains Mono, monospace", letterSpacing: "0.1em", display: "block", marginBottom: "0.35rem" }}>
                        DESCRIPCIÓN
                      </label>
                      <textarea
                        rows={3}
                        value={incident.descripcion}
                        onChange={e => setIncident(p => ({ ...p, descripcion: e.target.value }))}
                        placeholder="Describe brevemente la situación..."
                        style={{ width: "100%", background: "#111927", border: "1px solid #1e2d42", color: "#e2eaf4", padding: "0.6rem 0.75rem", borderRadius: "2px", fontFamily: "Inter, sans-serif", fontSize: "0.875rem", outline: "none", resize: "vertical" }}
                      />
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab("asignacion")}
                    disabled={!incident.tipo || !incident.nivel}
                    style={{
                      marginTop: "1.25rem",
                      background: incident.tipo && incident.nivel ? "#e63946" : "#1e2d42",
                      color: incident.tipo && incident.nivel ? "#fff" : "#2a3f5a",
                      fontFamily: "Barlow Condensed, sans-serif",
                      fontSize: "0.9rem",
                      fontWeight: 700,
                      letterSpacing: "0.1em",
                      textTransform: "uppercase",
                      padding: "0.65rem 1.5rem",
                      border: "none",
                      borderRadius: "2px",
                      cursor: incident.tipo && incident.nivel ? "pointer" : "default",
                    }}
                  >
                    Continuar → Asignación
                  </button>
                </div>
              )}

              {/* ── Tab: Asignación automática ─────────────────── */}
              {activeTab === "asignacion" && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h2 style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "1.4rem", fontWeight: 700, color: "#e2eaf4", letterSpacing: "0.05em", textTransform: "uppercase" }}>
                      Asignación Automática
                    </h2>
                    <div style={{ color: "#5a7a99", fontSize: "0.68rem", fontFamily: "JetBrains Mono, monospace" }}>
                      ALGORITMO: DIJKSTRA + PRIORIDAD
                    </div>
                  </div>

                  {/* tipo tags */}
                  <div className="flex gap-2 mb-5">
                    {["Ambulancias", "Bomberos", "Rescate"].map((t, i) => {
                      const colors = ["#1d8cf8", "#f4a261", "#2dc653"];
                      return (
                        <span key={t} style={{ background: colors[i] + "18", border: `1px solid ${colors[i]}40`, color: colors[i], fontSize: "0.72rem", fontFamily: "JetBrains Mono, monospace", padding: "0.25rem 0.75rem", borderRadius: "2px" }}>
                          {t}
                        </span>
                      );
                    })}
                  </div>

                  <div style={{ border: "1px solid #1e2d42", borderRadius: "2px", overflow: "hidden" }}>
                    {/* table header */}
                    <div className="grid text-xs" style={{ gridTemplateColumns: "1fr 1.2fr 1fr 1fr 80px 80px", background: "#111927", borderBottom: "1px solid #1e2d42", padding: "0.5rem 0.75rem", fontFamily: "JetBrains Mono, monospace", color: "#2a3f5a", gap: "0.5rem" }}>
                      <span>UNIDAD</span><span>TIPO</span><span>ESTADO</span><span>UBICACIÓN</span><span>DIST.</span><span>PRIORIDAD</span>
                    </div>
                    {RESOURCES.map((r, i) => (
                      <div
                        key={r.id}
                        className="grid items-center text-sm"
                        style={{
                          gridTemplateColumns: "1fr 1.2fr 1fr 1fr 80px 80px",
                          padding: "0.65rem 0.75rem",
                          gap: "0.5rem",
                          borderBottom: i < RESOURCES.length - 1 ? "1px solid #1e2d4260" : "none",
                          background: assigned?.id === r.id ? "#e6394612" : "transparent",
                          borderLeft: assigned?.id === r.id ? "2px solid #e63946" : "2px solid transparent",
                        }}
                      >
                        <span style={{ fontFamily: "JetBrains Mono, monospace", color: "#e2eaf4", fontSize: "0.8rem" }}>{r.id}</span>
                        <span style={{ color: "#5a7a99", fontSize: "0.8rem" }}>{r.unidad}</span>
                        <StatusBadge estado={r.estado} />
                        <span style={{ color: "#5a7a99", fontSize: "0.75rem" }}>{r.ubicacion}</span>
                        <span style={{ fontFamily: "JetBrains Mono, monospace", color: "#f4a261", fontSize: "0.8rem" }}>{r.distancia}km</span>
                        <span style={{ fontFamily: "JetBrains Mono, monospace", color: r.prioridad === 1 ? "#e63946" : "#5a7a99", fontSize: "0.8rem" }}>#{r.prioridad}</span>
                      </div>
                    ))}
                  </div>

                  {!assigned ? (
                    <button
                      onClick={handleAssign}
                      style={{ marginTop: "1.25rem", background: "#e63946", color: "#fff", fontFamily: "Barlow Condensed, sans-serif", fontSize: "0.9rem", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", padding: "0.65rem 1.5rem", border: "none", borderRadius: "2px", cursor: "pointer" }}
                    >
                      ⚡ Ejecutar asignación automática
                    </button>
                  ) : (
                    <div style={{ marginTop: "1.25rem", background: "#2dc65316", border: "1px solid #2dc65340", borderRadius: "2px", padding: "1rem 1.25rem" }}>
                      <p style={{ color: "#2dc653", fontFamily: "JetBrains Mono, monospace", fontSize: "0.75rem", marginBottom: "0.25rem" }}>✓ UNIDAD ASIGNADA</p>
                      <p style={{ color: "#e2eaf4", fontFamily: "Barlow Condensed, sans-serif", fontSize: "1.2rem", fontWeight: 700 }}>
                        {assigned.id} — {assigned.unidad} · {assigned.distancia}km
                      </p>
                      <p style={{ color: "#5a7a99", fontSize: "0.8rem", marginTop: "0.15rem" }}>ETA estimado: {Math.round(assigned.distancia * 1.8)} min</p>
                    </div>
                  )}
                </div>
              )}

              {/* ── Tab: Rutas de emergencia ───────────────────── */}
              {activeTab === "rutas" && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h2 style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "1.4rem", fontWeight: 700, color: "#e2eaf4", letterSpacing: "0.05em", textTransform: "uppercase" }}>
                      Rutas de Emergencia
                    </h2>
                    <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: "0.65rem", color: "#5a7a99" }}>
                      ALGORITMO: GRAFO DE CAMINO MÍN.
                    </div>
                  </div>

                  <div className="grid gap-4" style={{ gridTemplateColumns: "1fr 1fr" }}>
                    <div style={{ border: "1px solid #1e2d42", borderRadius: "2px", overflow: "hidden" }}>
                      <div style={{ background: "#111927", padding: "0.5rem 0.75rem", borderBottom: "1px solid #1e2d42", fontFamily: "JetBrains Mono, monospace", fontSize: "0.65rem", color: "#2a3f5a", letterSpacing: "0.1em" }}>
                        VISUALIZACIÓN DE GRAFO
                      </div>
                      <GraphView highlightOptimal={showGraph} />
                    </div>

                    <div className="flex flex-col gap-3">
                      {/* legend */}
                      <div style={{ border: "1px solid #1e2d42", borderRadius: "2px", padding: "0.75rem" }}>
                        <p style={{ fontFamily: "JetBrains Mono, monospace", fontSize: "0.65rem", color: "#2a3f5a", marginBottom: "0.5rem", letterSpacing: "0.1em" }}>NODOS</p>
                        {[
                          { color: "#e63946", label: "Incidente" },
                          { color: "#1d8cf8", label: "Unidad de respuesta" },
                          { color: "#2dc653", label: "Hospital" },
                          { color: "#f4a261", label: "Base" },
                        ].map(({ color, label }) => (
                          <div key={label} className="flex items-center gap-2 mb-1">
                            <div className="w-2.5 h-2.5 rounded-full" style={{ background: color }} />
                            <span style={{ color: "#5a7a99", fontSize: "0.78rem", fontFamily: "Inter, sans-serif" }}>{label}</span>
                          </div>
                        ))}
                      </div>

                      {/* optimal route */}
                      <div style={{ border: "1px solid #1e2d42", borderRadius: "2px", padding: "0.75rem" }}>
                        <p style={{ fontFamily: "JetBrains Mono, monospace", fontSize: "0.65rem", color: "#2a3f5a", marginBottom: "0.5rem", letterSpacing: "0.1em" }}>RUTA ÓPTIMA</p>
                        <div className="flex items-center gap-1 flex-wrap">
                          {["AMB-01", "→ 3.2km →", "INCIDENTE", "→ 2.1km →", "HOSPITAL"].map((s, i) => (
                            <span
                              key={i}
                              style={{
                                fontFamily: "JetBrains Mono, monospace",
                                fontSize: "0.72rem",
                                color: s.includes("→") ? "#5a7a99" : "#e2eaf4",
                                background: s.includes("→") ? "transparent" : "#1e2d42",
                                padding: s.includes("→") ? "0" : "0.15rem 0.4rem",
                                borderRadius: "2px",
                              }}
                            >
                              {s}
                            </span>
                          ))}
                        </div>
                        <p style={{ color: "#2dc653", fontSize: "0.72rem", fontFamily: "JetBrains Mono, monospace", marginTop: "0.4rem" }}>
                          Costo total: 5.3km — ETA: 9 min
                        </p>
                      </div>

                      <button
                        onClick={() => setShowGraph(v => !v)}
                        style={{
                          background: showGraph ? "#e63946" : "#1e2d42",
                          color: showGraph ? "#fff" : "#5a7a99",
                          fontFamily: "Barlow Condensed, sans-serif",
                          fontSize: "0.85rem",
                          fontWeight: 700,
                          letterSpacing: "0.1em",
                          textTransform: "uppercase",
                          padding: "0.6rem 1rem",
                          border: "none",
                          borderRadius: "2px",
                          cursor: "pointer",
                          transition: "all 0.15s",
                        }}
                      >
                        {showGraph ? "Ocultar ruta óptima" : "Mostrar ruta óptima"}
                      </button>
                    </div>
                  </div>

                  {/* algo info */}
                  <div style={{ marginTop: "1.25rem", background: "#111927", border: "1px solid #1e2d42", borderRadius: "2px", padding: "0.85rem 1rem" }}>
                    <p style={{ fontFamily: "JetBrains Mono, monospace", fontSize: "0.65rem", color: "#2a3f5a", marginBottom: "0.35rem", letterSpacing: "0.1em" }}>DESCRIPCIÓN DEL ALGORITMO</p>
                    <p style={{ color: "#5a7a99", fontSize: "0.82rem", lineHeight: 1.6 }}>
                      Se modela la red de respuesta como un <span style={{ color: "#e2eaf4" }}>grafo ponderado</span> G = (V, E) donde los vértices representan
                      unidades, incidentes y hospitales, y las aristas contienen el costo de la ruta (distancia × factor de tráfico).
                      El algoritmo de <span style={{ color: "#1d8cf8" }}>Dijkstra</span> calcula el camino de menor costo desde cada unidad disponible al incidente,
                      combinado con una <span style={{ color: "#f4a261" }}>función de prioridad</span> que pondera urgencia, capacidad y tipo de recurso.
                    </p>
                  </div>
                </div>
              )}

              {/* ── Tab: Inventario ───────────────────────────── */}
              {activeTab === "inventario" && (
                <div>
                  <h2 style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "1.4rem", fontWeight: 700, color: "#e2eaf4", letterSpacing: "0.05em", textTransform: "uppercase", marginBottom: "1.25rem" }}>
                    Inventario de Recursos
                  </h2>

                  <div className="grid gap-3" style={{ gridTemplateColumns: "repeat(3, 1fr)" }}>
                    {[
                      { label: "Ambulancias", total: 4, disp: 2, color: "#1d8cf8" },
                      { label: "Bomberos",    total: 3, disp: 1, color: "#f4a261" },
                      { label: "Rescate",     total: 3, disp: 1, color: "#2dc653" },
                    ].map(({ label, total, disp, color }) => (
                      <div key={label} style={{ background: "#111927", border: "1px solid #1e2d42", borderRadius: "2px", padding: "1rem" }}>
                        <p style={{ fontFamily: "JetBrains Mono, monospace", fontSize: "0.65rem", color: "#2a3f5a", letterSpacing: "0.1em", marginBottom: "0.4rem" }}>{label.toUpperCase()}</p>
                        <p style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "2rem", fontWeight: 800, color, lineHeight: 1 }}>{disp}</p>
                        <p style={{ fontFamily: "JetBrains Mono, monospace", fontSize: "0.7rem", color: "#5a7a99", marginTop: "0.15rem" }}>de {total} disponibles</p>
                        <div className="mt-3" style={{ background: "#1e2d42", borderRadius: "2px", height: "4px" }}>
                          <div style={{ background: color, width: `${(disp / total) * 100}%`, height: "100%", borderRadius: "2px" }} />
                        </div>
                      </div>
                    ))}
                  </div>

                  <div style={{ marginTop: "1.25rem", border: "1px solid #1e2d42", borderRadius: "2px", overflow: "hidden" }}>
                    <div style={{ background: "#111927", borderBottom: "1px solid #1e2d42", padding: "0.5rem 0.75rem", fontFamily: "JetBrains Mono, monospace", fontSize: "0.65rem", color: "#2a3f5a", letterSpacing: "0.1em" }}>
                      DETALLE DE UNIDADES
                    </div>
                    {RESOURCES.map((r, i) => (
                      <div key={r.id} style={{ display: "flex", alignItems: "center", gap: "1rem", padding: "0.65rem 0.75rem", borderBottom: i < RESOURCES.length - 1 ? "1px solid #1e2d4260" : "none" }}>
                        <span style={{ fontFamily: "JetBrains Mono, monospace", color: "#e2eaf4", fontSize: "0.8rem", minWidth: "80px" }}>{r.id}</span>
                        <span style={{ color: "#5a7a99", fontSize: "0.8rem", flex: 1 }}>{r.unidad}</span>
                        <span style={{ color: "#5a7a99", fontSize: "0.75rem", flex: 1 }}>{r.tipo}</span>
                        <StatusBadge estado={r.estado} />
                        <span style={{ fontFamily: "JetBrains Mono, monospace", color: "#f4a261", fontSize: "0.75rem", minWidth: "60px", textAlign: "right" }}>{r.distancia}km</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── Reportes section ───────────────────────────────────── */}
        {submitted && (
          <div style={{ marginTop: "2.5rem" }}>
            <div className="flex items-center gap-3 mb-4">
              <span style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "1.1rem", fontWeight: 700, color: "#5a7a99", letterSpacing: "0.1em", textTransform: "uppercase" }}>
                Reportes
              </span>
              <div style={{ flex: 1, height: "1px", background: "#1e2d42" }} />
            </div>

            {/* step pipeline */}
            <div style={{ border: "1px solid #1e2d42", borderRadius: "2px", background: "#0d1420", padding: "1.5rem" }}>
              <div className="flex items-start gap-0" style={{ overflowX: "auto", paddingBottom: "0.5rem" }}>
                {STEPS.map((s, i) => (
                  <div key={i} className="flex items-start" style={{ minWidth: "160px" }}>
                    <div className="flex flex-col items-center" style={{ width: "100%" }}>
                      <div className="flex items-center w-full">
                        <div
                          className={stepClass(i)}
                          style={{
                            width: "28px", height: "28px", borderRadius: "50%",
                            display: "flex", alignItems: "center", justifyContent: "center",
                            fontFamily: "JetBrains Mono, monospace", fontSize: "0.75rem", fontWeight: 700,
                            flexShrink: 0,
                          }}
                        >
                          {i < reportStep ? "✓" : i + 1}
                        </div>
                        {i < STEPS.length - 1 && (
                          <div style={{ flex: 1, height: "2px", background: i < reportStep ? "#2dc653" : "#1e2d42", marginLeft: "0.25rem" }} />
                        )}
                      </div>
                      <div style={{ marginTop: "0.5rem", paddingRight: "0.5rem" }}>
                        <p style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "0.82rem", fontWeight: 700, color: i === reportStep ? "#e2eaf4" : i < reportStep ? "#2dc653" : "#2a3f5a", letterSpacing: "0.03em", textTransform: "uppercase" }}>
                          {s.label}
                        </p>
                        <p style={{ fontFamily: "Inter, sans-serif", fontSize: "0.7rem", color: "#2a3f5a", marginTop: "0.1rem", lineHeight: 1.4 }}>
                          {s.desc}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* step action */}
              {reportStep < 5 && (
                <div style={{ marginTop: "1.5rem", display: "flex", gap: "0.75rem", alignItems: "center" }}>
                  <button
                    onClick={() => setReportStep(s => (s < 5 ? (s + 1) as ReportStep : 5))}
                    style={{
                      background: "#e63946",
                      color: "#fff",
                      fontFamily: "Barlow Condensed, sans-serif",
                      fontSize: "0.875rem",
                      fontWeight: 700,
                      letterSpacing: "0.1em",
                      textTransform: "uppercase",
                      padding: "0.55rem 1.25rem",
                      border: "none",
                      borderRadius: "2px",
                      cursor: "pointer",
                    }}
                  >
                    {reportStep === 0 ? "Iniciar reporte" : "Siguiente paso →"}
                  </button>
                  {reportStep > 0 && (
                    <button
                      onClick={() => setReportStep(s => (s > 0 ? (s - 1) as ReportStep : 0))}
                      style={{ background: "transparent", color: "#5a7a99", fontFamily: "JetBrains Mono, monospace", fontSize: "0.75rem", border: "1px solid #1e2d42", padding: "0.5rem 0.85rem", borderRadius: "2px", cursor: "pointer" }}
                    >
                      ← Atrás
                    </button>
                  )}
                  <span style={{ fontFamily: "JetBrains Mono, monospace", color: "#2a3f5a", fontSize: "0.68rem" }}>
                    Paso {reportStep + 1} de {STEPS.length}
                  </span>
                </div>
              )}

              {reportStep === 5 && (
                <div style={{ marginTop: "1.25rem", background: "#2dc65316", border: "1px solid #2dc65340", borderRadius: "2px", padding: "0.85rem 1rem" }}>
                  <p style={{ color: "#2dc653", fontFamily: "JetBrains Mono, monospace", fontSize: "0.75rem", marginBottom: "0.15rem" }}>
                    ✓ REPORTE COMPLETADO — UNIDAD DESPACHADA
                  </p>
                  <p style={{ color: "#e2eaf4", fontFamily: "Inter, sans-serif", fontSize: "0.85rem" }}>
                    {assigned
                      ? `${assigned.id} (${assigned.unidad}) asignada al incidente en "${address}"`
                      : `Proceso de reporte finalizado para "${address}"`}
                  </p>
                  <button
                    onClick={() => { setReportStep(0); setAssigned(null); }}
                    style={{ marginTop: "0.75rem", background: "transparent", color: "#5a7a99", fontFamily: "JetBrains Mono, monospace", fontSize: "0.72rem", border: "1px solid #1e2d42", padding: "0.4rem 0.85rem", borderRadius: "2px", cursor: "pointer" }}
                  >
                    Nuevo reporte
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

      </div>

      {/* footer */}
      <div style={{ borderTop: "1px solid #1e2d42", padding: "0.75rem 1.5rem", marginTop: "2rem", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ fontFamily: "JetBrains Mono, monospace", color: "#1e2d42", fontSize: "0.65rem" }}>EMRG·SYS · Sistema de Gestión de Emergencias</span>
        <span style={{ fontFamily: "JetBrains Mono, monospace", color: "#1e2d42", fontSize: "0.65rem" }}>Dijkstra Graph Routing © 2026</span>
      </div>
    </div>
  );
}
